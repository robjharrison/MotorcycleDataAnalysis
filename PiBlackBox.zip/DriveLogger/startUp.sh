#!/bin/sh
cd /
cd home/pi/DriveLogger/
sudo python3 driveData.py &
sudo python3 driveCam.py &
exit 0
cd /

